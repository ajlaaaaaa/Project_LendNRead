﻿namespace Lend_N_Read
{
    partial class FormGenre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelRomance = new System.Windows.Forms.Label();
            this.labelThriller = new System.Windows.Forms.Label();
            this.labelScienceFiction = new System.Windows.Forms.Label();
            this.labelReligion = new System.Windows.Forms.Label();
            this.labelMystery = new System.Windows.Forms.Label();
            this.labelBusiness = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelRomance
            // 
            this.labelRomance.AutoSize = true;
            this.labelRomance.Font = new System.Drawing.Font("Sitka Small", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRomance.Location = new System.Drawing.Point(119, 81);
            this.labelRomance.Name = "labelRomance";
            this.labelRomance.Size = new System.Drawing.Size(72, 19);
            this.labelRomance.TabIndex = 6;
            this.labelRomance.Text = "Romance";
            // 
            // labelThriller
            // 
            this.labelThriller.AutoSize = true;
            this.labelThriller.Font = new System.Drawing.Font("Sitka Small", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelThriller.Location = new System.Drawing.Point(324, 81);
            this.labelThriller.Name = "labelThriller";
            this.labelThriller.Size = new System.Drawing.Size(64, 19);
            this.labelThriller.TabIndex = 7;
            this.labelThriller.Text = "Thriller";
            // 
            // labelScienceFiction
            // 
            this.labelScienceFiction.AutoSize = true;
            this.labelScienceFiction.Font = new System.Drawing.Font("Sitka Small", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelScienceFiction.Location = new System.Drawing.Point(119, 305);
            this.labelScienceFiction.Name = "labelScienceFiction";
            this.labelScienceFiction.Size = new System.Drawing.Size(114, 19);
            this.labelScienceFiction.TabIndex = 8;
            this.labelScienceFiction.Text = "Science Fiction";
            // 
            // labelReligion
            // 
            this.labelReligion.AutoSize = true;
            this.labelReligion.Font = new System.Drawing.Font("Sitka Small", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReligion.Location = new System.Drawing.Point(324, 305);
            this.labelReligion.Name = "labelReligion";
            this.labelReligion.Size = new System.Drawing.Size(67, 19);
            this.labelReligion.TabIndex = 9;
            this.labelReligion.Text = "Religion";
            // 
            // labelMystery
            // 
            this.labelMystery.AutoSize = true;
            this.labelMystery.Font = new System.Drawing.Font("Sitka Small", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMystery.Location = new System.Drawing.Point(545, 305);
            this.labelMystery.Name = "labelMystery";
            this.labelMystery.Size = new System.Drawing.Size(66, 19);
            this.labelMystery.TabIndex = 10;
            this.labelMystery.Text = "Mystery";
            // 
            // labelBusiness
            // 
            this.labelBusiness.AutoSize = true;
            this.labelBusiness.Font = new System.Drawing.Font("Sitka Small", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBusiness.Location = new System.Drawing.Point(541, 81);
            this.labelBusiness.Name = "labelBusiness";
            this.labelBusiness.Size = new System.Drawing.Size(70, 19);
            this.labelBusiness.TabIndex = 11;
            this.labelBusiness.Text = "Business";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe Print", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(333, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 47);
            this.label7.TabIndex = 12;
            this.label7.Text = "Genre";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Lend_N_Read.Properties.Resources.science_fiction;
            this.pictureBox5.Location = new System.Drawing.Point(123, 327);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(146, 170);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 16;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Lend_N_Read.Properties.Resources.religion;
            this.pictureBox4.Location = new System.Drawing.Point(328, 327);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(146, 170);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 15;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Lend_N_Read.Properties.Resources.mystery;
            this.pictureBox3.Location = new System.Drawing.Point(548, 327);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(146, 170);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 14;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Lend_N_Read.Properties.Resources.business;
            this.pictureBox7.Location = new System.Drawing.Point(545, 103);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(146, 170);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 13;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Lend_N_Read.Properties.Resources.Thriller;
            this.pictureBox2.Location = new System.Drawing.Point(325, 103);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(146, 170);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Lend_N_Read.Properties.Resources.Romance;
            this.pictureBox1.Location = new System.Drawing.Point(120, 103);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(144, 170);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // FormGenre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 553);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelBusiness);
            this.Controls.Add(this.labelMystery);
            this.Controls.Add(this.labelReligion);
            this.Controls.Add(this.labelScienceFiction);
            this.Controls.Add(this.labelThriller);
            this.Controls.Add(this.labelRomance);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormGenre";
            this.Text = "Genre";
            this.Load += new System.EventHandler(this.FormGenre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label labelRomance;
        private System.Windows.Forms.Label labelThriller;
        private System.Windows.Forms.Label labelScienceFiction;
        private System.Windows.Forms.Label labelReligion;
        private System.Windows.Forms.Label labelMystery;
        private System.Windows.Forms.Label labelBusiness;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}

